import serial
import time
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect

# Initialize serial connection
ser = serial.Serial('COM3', 9600, timeout=1)


def tell_story(request):
    answer = ""
    if request.method == 'POST':
        story = request.POST.get('story')
        try:
            ser.write((story + '\n').encode())
            answer = "Story sent to Arduino!"
        except Exception as e:
            answer = f"Error: {e}"
    return render(request, 'tell_story.html', {'answer': answer})

def ask_arduino(request):
    answer = ""
    if request.method == 'POST':
        question = request.POST.get('question')
        try:
            ser.write((question + '\n').encode())
            answer = ser.readline().decode().strip()
        except Exception as e:
            answer = f"Error: {e}"
    return render(request, 'ask_arduino.html', {'answer': answer})

def robot_interact(request):
    tell_answer = ""
    ask_answer = ""
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'tell':
            story = request.POST.get('story')
            try:
                ser.write((story + '\n').encode())
                tell_answer = "Story sent to Arduino!"
            except Exception as e:
                tell_answer = f"Error: {e}"
        elif action == 'ask':
            question = request.POST.get('question')
            try:
                ser.reset_input_buffer()  # Clear old data
                ser.write((question + '\n').encode())
                time.sleep(0.2)  # Small delay for Arduino to respond
                ask_answer = ser.readline().decode().strip()
            except Exception as e:
                ask_answer = f"Error: {e}"
    return render(request, 'robot_interact.html', {
        'tell_answer': tell_answer,
        'ask_answer': ask_answer
    })

def tell_about_yourself(request):
    tell_answer = ""
    if request.method == 'POST':
        story = request.POST.get('story')
        try:
            ser.write((story + '\n').encode())
            tell_answer = "Story sent to the robot!"
        except Exception as e:
            tell_answer = f"Error: {e}"
    return render(request, 'tell_about_yourself.html', {'tell_answer': tell_answer})

def ask_robot(request):
    ask_answer = ""
    if request.method == 'POST':
        question = request.POST.get('question')
        try:
            ser.reset_input_buffer()
            ser.write((question + '\n').encode())
            time.sleep(0.2)
            ask_answer = ser.readline().decode().strip()
        except Exception as e:
            ask_answer = f"Error: {e}"
    return render(request, 'ask_robot.html', {'ask_answer': ask_answer})
