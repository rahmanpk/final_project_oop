from django.urls import path
from . import views


urlpatterns = [
    path('tell/', views.tell_about_yourself, name='tell_about_yourself'),
    path('ask/', views.ask_robot, name='ask_robot'),
]
